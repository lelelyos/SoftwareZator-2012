﻿Public Class $safeitemname$
    Inherits VelerSoftware.Plugins3.ActionForm

    ' This Sub is run when the form opens. 
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        With Me
            .CancelButtonText = RM.GetString("CancelButtonText")
            .Title = RM.GetString("DisplayName")
            .Help_File = RM.GetString("Help_File")

            .ParseCode_Button_Visible = True

            ' .MyControl.Text = .Param1

            ' Here, the initialization of the Form.
            ' You should load the values of Param# properties from this class
        End With
    End Sub

    ' This Sub is run when user click on OK button
    Private Sub Form1_OnOKButtonClicked(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.OnOKButtonClicked
        With Me
            ' Here, you should test if the user has completed the Form 
            ' and save the user's data in the Param# properties of this class.
            ' This properties will be used by you Action class to save
            ' the settings of your Action.

            ' .Param1 = .MyControl.Text

            .DialogResult = Windows.Forms.DialogResult.OK
            .Close()
        End With
    End Sub

    ' This Sub is run when user click on Cancel button
    Private Sub Form1_OnCancelButtonClicked(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.OnCancelButtonClicked
        With Me
            .DialogResult = Windows.Forms.DialogResult.Cancel
            .Close()
        End With
    End Sub

    ' This Sub is run when user wants to view the VB.Net code and click on Refresh button
    Private Sub Form1_OnRefreshCodeButtonClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.OnRefreshCodeButtonClick
        ' Here, you should (with CodeDom or not) generate the Visual Basic.Net code according to
        ' what the user has completed the Form.

        Dim sourceWriter As New IO.StringWriter()

        CodeDom.Compiler.CodeDomProvider.CreateProvider("VB").GenerateCodeFromStatement(New CodeDom.CodeAssignStatement(New CodeDom.CodeVariableReferenceExpression("MyVariable"), New CodeDom.CodeSnippetExpression("1")), sourceWriter, New CodeDom.Compiler.CodeGeneratorOptions())

        sourceWriter.Close()

        Me.CodeEditor_Text = sourceWriter.ToString
    End Sub

    ' This Sub is run when user wants to change the action's settings according to the VB.Net code
    Private Sub Form1_OnParseCodeButtonClick(ByVal sender As CodeDom.CodeCompileUnit, ByVal e As System.EventArgs) Handles MyBase.OnParseCodeButtonClick
        If (Not sender Is Nothing) AndAlso (sender.Namespaces.Count > 0) Then

            ' Here, you should write an algorithm to reload the Form with the VB.Net code
            ' according to exclusively System.CodeDom. 

        End If
    End Sub

End Class