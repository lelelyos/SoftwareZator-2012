﻿Public Class EditAVariable_Form
    Inherits VelerSoftware.Plugins3.ActionForm

    ' This Sub is run when the form opens. 
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        With Me
            .CancelButtonText = RM.GetString("CancelButtonText")
            .Title = RM.GetString("DisplayName")
            .Help_File = RM.GetString("Help_File")

            .ParseCode_Button_Visible = True

            ' Here, the initialization of the Form.
            ' You should load the values of Param# properties from this class 

            .ValueEdit1.Tools = .Tools

            .ComboBox1.SelectedIndex = 0
            .ComboBox1.Items.Clear()
            For Each a As VelerSoftware.SZVB.Projet.Variable In .Tools.GetCurrentProjectVariableList
                If Not a.Array Then
                    .ComboBox1.Items.Add(a.Name)
                End If
            Next

            If Not .Param1 = Nothing Then
                If Not .ComboBox1.FindString(.Param1) = -1 Then
                    .ComboBox1.Text = .ComboBox1.Items(.ComboBox1.FindString(.Param1))
                End If
            End If

            If Not .Param3 = Nothing Then
                .ValueEdit1.SetGeneratedCode(.Param3)
            End If

            If Not .Param2 = Nothing Then
                .ValueEdit1.SetStrictValue(.Param2, CInt(.Param4))
            End If
        End With
    End Sub

    ' This Sub is run when user click on OK button
    Private Sub Form1_OnOKButtonClicked(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.OnOKButtonClicked
        With Me
            ' Here, you should test if the user has completed the Form 
            ' and save the user's data in the Param# properties of this class.
            ' This properties will be used by you Action class to save
            ' the settings of your Action.

            If .ComboBox1.Text = Nothing Then
                MsgBox(RM.GetString("Incompleted_Form"), MsgBoxStyle.Exclamation)
                Exit Sub
            End If

            .Param1 = .ComboBox1.Text
            .Param2 = .ValueEdit1.GetStrictValue()
            .Param4 = CInt(.ValueEdit1.Editor)
            .Param3 = .ValueEdit1.GetGeneratedCode()

            .DialogResult = Windows.Forms.DialogResult.OK
            .Close()
        End With
    End Sub

    ' This Sub is run when user click on Cancel button
    Private Sub Form1_OnCancelButtonClicked(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.OnCancelButtonClicked
        With Me
            .DialogResult = Windows.Forms.DialogResult.Cancel
            .Close()
        End With
    End Sub

    ' This Sub is run when user wants to view the VB.Net code and click on Refresh button
    Private Sub Form1_OnRefreshCodeButtonClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.OnRefreshCodeButtonClick
        ' Here, you should (with CodeDom or not) generate the Visual Basic.Net code according to
        ' what the user has completed the Form.

        If Me.ComboBox1.Text = Nothing Then
            MsgBox(RM.GetString("Incompleted_Form"), MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        Dim sourceWriter As New IO.StringWriter()

        Dim VariableStatement As New CodeDom.CodeVariableReferenceExpression(Me.ComboBox1.Text)
        Dim NewValueStatement As New CodeDom.CodeSnippetExpression(Me.ValueEdit1.GetGeneratedCode())
        Dim OperationStatement As New CodeDom.CodeAssignStatement(VariableStatement, NewValueStatement)
        CodeDom.Compiler.CodeDomProvider.CreateProvider("VB").GenerateCodeFromStatement(OperationStatement, sourceWriter, New CodeDom.Compiler.CodeGeneratorOptions())

        sourceWriter.Close()

        Me.CodeEditor_Text = sourceWriter.ToString
    End Sub

    ' This Sub is run when user wants to change the action's settings according to the VB.Net code
    Private Sub Form1_OnParseCodeButtonClick(ByVal sender As CodeDom.CodeCompileUnit, ByVal e As System.EventArgs) Handles MyBase.OnParseCodeButtonClick
        If (Not sender Is Nothing) AndAlso (sender.Namespaces.Count > 0) Then

            ' Here, you should write an algorithm to reload the Form with the VB.Net code
            ' according to exclusively System.CodeDom. 

            Dim metho As CodeDom.CodeAssignStatement
            For Each sta As CodeDom.CodeStatement In DirectCast(sender.Namespaces(0).Types(0).Members(0), CodeDom.CodeMemberMethod).Statements

                If TypeOf sta Is CodeDom.CodeAssignStatement Then
                    metho = DirectCast(sta, CodeDom.CodeAssignStatement)
                    If TypeOf metho.Left Is CodeDom.CodeVariableReferenceExpression Then
                        Me.ComboBox1.Text = DirectCast(metho.Left, CodeDom.CodeVariableReferenceExpression).VariableName
                    End If
                End If
            Next

        End If
    End Sub

End Class