﻿' The line below defines the designer of the action (a Action_Designer.xaml file) to use for the action editor.
<System.ComponentModel.Designer(GetType(EditAVariable_Designer))> _
Public Class EditAVariable
    ' This file is itself an "action". This is where you will be defined the main properties of the action. To define a class as an
    ' action, you must inherit this class of "VelerSoftware.Plugins3.Action" (having previously added the reference 
    ' "VelerSoftware.Plugins3.dll" to the project.
    Inherits VelerSoftware.Plugins3.Action

    ' The Sub "New" is performed during initialization of the action, at the start of SoftwareZator, before it is loaded into the Toolbox.
    ' It is here that sets the title of the action, its icon, description, category, the parameters of speech recognition and more.
    Public Sub New()
        ' Initialization of the language and resources
        System.Threading.Thread.CurrentThread.CurrentUICulture = VelerSoftware.Plugins3.CurrentCulture
        RM = New System.Resources.ResourceManager("$safeprojectname$.EditAVariable", GetType(EditAVariable).Assembly)

        ' Initializing Properties basis for action
        With Me
            .DisplayName = RM.GetString("DisplayName") ' Name displayed in the Toolbox
            .Description = RM.GetString("Description") ' Description displayed in the Toolbox
            .Category = RM.GetString("Category") ' Action's category
            .ToolBoxImage = My.Resources.EditAVariable ' Icon of the action
            .CompatibleClass = False ' If this property is True, this action will be shown in the Toolbox when the user is in the root (first tab) of the functions editor
            .CompatibleFonctions = True ' If this property is True, this action will be shown in the Toobox when ther user is in a function
            .FileHelp = RM.GetString("Help_File") ' Define the HTML file for the documentation of the action

            .Voice_Recognition_Dictionary.Add(RM.GetString("Dictionary1")) ' Add a word to the dictionary for the voice recognition
            .Voice_Recognition_Dictionary.Add(RM.GetString("Dictionary2"))
        End With
    End Sub

    ' The "Main" function is executed when the action is added to the action editor. Its purpose is to ask the user to set it, usually by 
    ' displaying a window on the screen. We then return a Boolean value to allows or not whether SoftwareZator can add the action to the
    ' action editor or if the user canceled the addition of this action.
    Public Overrides Function Main() As Boolean
        ' Initialization of the language and resources
        System.Threading.Thread.CurrentThread.CurrentUICulture = VelerSoftware.Plugins3.CurrentCulture
        RM = New System.Resources.ResourceManager("$safeprojectname$.EditAVariable", GetType(EditAVariable).Assembly)

        ' Displaying the setting window of the action
        Using frm As New EditAVariable_Form
            frm.Tools = Me.Tools ' Property Tools can use the various functions issued by VelerSoftware.Plugins3.Tools
            If frm.ShowDialog = Windows.Forms.DialogResult.OK Then
                Me.UseCustomVBCode = frm.CodeEditor_Used
                Me.CustomVBCode = New CodeDom.CodeSnippetStatement(frm.CodeEditor_Text)
                Me.Param1 = frm.Param1 ' Retrieve a setting to save it   
                Me.Param2 = frm.Param2
                Me.Param3 = frm.Param3
                Me.Param4 = frm.Param4

                Return True
            Else
                Return False
            End If
            frm.Dispose()
        End Using
    End Function

    ' The "Modify" function is executed when the user clicks the button "Change settings of action." Its purpose is to ask the user to
    ' set it, usually by displaying a window on the screen. We then return a Boolean value to allows or not whether SoftwareZator can
    ' change the settings of the action into the action editor or if the user canceled.
    Public Overrides Function Modify() As Boolean
        ' Initialization of the language and resources
        System.Threading.Thread.CurrentThread.CurrentUICulture = VelerSoftware.Plugins3.CurrentCulture
        RM = New System.Resources.ResourceManager("$safeprojectname$.EditAVariable", GetType(EditAVariable).Assembly)

        ' Displaying the setting window of the action
        Using frm As New EditAVariable_Form
            frm.Tools = Me.Tools ' Property Tools can use the various functions issued by VelerSoftware.Plugins3.Tools
            frm.Param1 = Me.Param1
            frm.Param2 = Me.Param2
            frm.Param3 = Me.Param3
            frm.Param4 = Me.Param4
            frm.CodeEditor_Shown = Me.UseCustomVBCode
            frm.CodeEditor_Used = Me.UseCustomVBCode

            ' Load the VB.Net code
            Dim sourceWriter As New IO.StringWriter()
            If Not Me.CustomVBCode Is Nothing Then CodeDom.Compiler.CodeDomProvider.CreateProvider("VB").GenerateCodeFromStatement(Me.CustomVBCode, sourceWriter, New CodeDom.Compiler.CodeGeneratorOptions())
            sourceWriter.Close()
            frm.CodeEditor_Text = sourceWriter.ToString

            If frm.ShowDialog = Windows.Forms.DialogResult.OK Then
                Me.UseCustomVBCode = frm.CodeEditor_Used
                Me.CustomVBCode = New CodeDom.CodeSnippetStatement(frm.CodeEditor_Text)
                Me.Param1 = frm.Param1 ' Retrieve a setting to save it    
                Me.Param2 = frm.Param2
                Me.Param3 = frm.Param3
                Me.Param4 = frm.Param4

                Return True
            Else
                Return False
            End If
            frm.Dispose()
        End Using
    End Function

    ' The "GetVBCode" function is called by SoftwareZator at the time of building a project to generate Visual Basic.Net code of the
    ' action to be compiled. The parameter "FromFunction" defined if the action is in a function or in the root of a document.
    ' You should return a CodeDom value. For more information on CodeDom:     
    ' http://msdn.microsoft.com/en-us/library/system.codedom(v=vs.100).aspx
    Public Overrides Function GetVBCode(ByVal FromFunction As Boolean) As System.CodeDom.CodeObject
        If Me.UseCustomVBCode Then
            Return Me.CustomVBCode
        Else
            If FromFunction Then
                ' Give a CodeDom value who generate the following vb.net code : Your_Variable = 1 with "Your_Variable", the value of Param1.
                Dim VariableStatement As New CodeDom.CodeVariableReferenceExpression(Me.Param1)
                Dim NewValueStatement As New CodeDom.CodeSnippetExpression(Me.Param3)
                Return New CodeDom.CodeAssignStatement(VariableStatement, NewValueStatement)
            Else
                Return Nothing
            End If
        End If
    End Function

    ' The "ResolveError" function is called when the user wants that SoftwareZator automatically fix a build error related to this action.
    ' In this function, you should write an algorithm designed to identify the problem with the parameter "ErrorToResolve", which
    ' delivers information about the error and allows to refer to SoftwareZator information related to the correction,
    ' such an explanation of the error.
    Public Overrides Function ResolveError(ByVal ErrorToResolve As VelerSoftware.SZVB.Projet.Erreur, ByVal e As System.EventArgs) As Boolean
        Dim result As Boolean
        Dim i_progress, i2_progress As Integer
        i_progress = 0
        i2_progress = 0

        System.Threading.Thread.CurrentThread.CurrentUICulture = VelerSoftware.Plugins3.CurrentCulture
        RM = New System.Resources.ResourceManager("$safeprojectname$.EditAVariable", GetType(EditAVariable).Assembly)

        If ErrorToResolve.Type = VelerSoftware.SZVB.Projet.Erreur.ErrorType.Building Then

            If ErrorToResolve.ErrorNumber = "BC30451" Then ' The variable no longer exists 
                Dim oki As Boolean
                For Each var As VelerSoftware.SZVB.Projet.Variable In Tools.GetCurrentProjectVariableList
                    If var.Name = Me.Param1 Then oki = True
                Next
                If Not oki Then Tools.GetCurrentProjectVariableList.Add(New VelerSoftware.SZVB.Projet.Variable(Me.Param1, False, Nothing, Nothing))
                ErrorToResolve.ErrorExplain = "The variable does not exist" ' Here, we explain what is the error
                ErrorToResolve.ErrorSolutionExplain = "The variable has been added to Variables Manager" ' And here, what correction has been found.

                Return True

            Else
                Return False

            End If

        End If

        Return result
    End Function

End Class
