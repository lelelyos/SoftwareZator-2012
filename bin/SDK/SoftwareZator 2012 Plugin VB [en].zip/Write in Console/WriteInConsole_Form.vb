﻿Public Class WriteInConsole_Form
    Inherits VelerSoftware.Plugins3.ActionForm

    ' This Sub is run when the form opens. 
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        With Me
            .CancelButtonText = RM.GetString("CancelButtonText")
            .Title = RM.GetString("DisplayName")
            .Help_File = RM.GetString("Help_File")

            .ParseCode_Button_Visible = True

            ' Here, the initialization of the Form.
            ' You should load the values of Param# properties from this class 

            .ActionTextBox1.Tools = .Tools

            .ActionTextBox1.Text = ""

            If Not .Param1 = Nothing Then .ActionTextBox1.Text = .Param1
        End With
    End Sub

    ' This Sub is run when user click on OK button
    Private Sub Form1_OnOKButtonClicked(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.OnOKButtonClicked
        With Me
            ' Here, you should test if the user has completed the Form 
            ' and save the user's data in the Param# properties of this class.
            ' This properties will be used by you Action class to save
            ' the settings of your Action.

            If .ActionTextBox1.Text = Nothing Then
                MsgBox(RM.GetString("Incompleted_Form"), MsgBoxStyle.Exclamation)
                Exit Sub
            End If

            .Param1 = .ActionTextBox1.Text

            .DialogResult = Windows.Forms.DialogResult.OK
            .Close()
        End With
    End Sub

    ' This Sub is run when user click on Cancel button
    Private Sub Form1_OnCancelButtonClicked(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.OnCancelButtonClicked
        With Me
            .DialogResult = Windows.Forms.DialogResult.Cancel
            .Close()
        End With
    End Sub

    ' This Sub is run when user wants to view the VB.Net code and click on Refresh button
    Private Sub Form1_OnRefreshCodeButtonClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.OnRefreshCodeButtonClick
        ' Here, you should (with CodeDom or not) generate the Visual Basic.Net code according to
        ' what the user has completed the Form.

        If Me.ActionTextBox1.Text = Nothing Then
            MsgBox(RM.GetString("Incompleted_Form"), MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        Dim sourceWriter As New IO.StringWriter()

        CodeDom.Compiler.CodeDomProvider.CreateProvider("VB").GenerateCodeFromExpression(New CodeDom.CodeMethodInvokeExpression(New CodeDom.CodeMethodReferenceExpression(New CodeDom.CodeTypeReferenceExpression("System.Console"), "WriteLine"), New CodeDom.CodeSnippetExpression(Me.Tools.TransformKeyVariables(Me.ActionTextBox1.Text, True))), sourceWriter, New CodeDom.Compiler.CodeGeneratorOptions())

        sourceWriter.Close()

        Me.CodeEditor_Text = sourceWriter.ToString
    End Sub

    ' This Sub is run when user wants to change the action's settings according to the VB.Net code
    Private Sub Form1_OnParseCodeButtonClick(ByVal sender As CodeDom.CodeCompileUnit, ByVal e As System.EventArgs) Handles MyBase.OnParseCodeButtonClick
        If (Not sender Is Nothing) AndAlso (sender.Namespaces.Count > 0) Then

            ' Here, you should write an algorithm to reload the Form with the VB.Net code
            ' according to exclusively System.CodeDom. 

            Dim metho As CodeDom.CodeMethodInvokeExpression
            For Each sta As CodeDom.CodeStatement In DirectCast(sender.Namespaces(0).Types(0).Members(0), CodeDom.CodeMemberMethod).Statements
                If TypeOf sta Is CodeDom.CodeExpressionStatement AndAlso TypeOf DirectCast(sta, CodeDom.CodeExpressionStatement).Expression Is CodeDom.CodeMethodInvokeExpression Then
                    ' If it is a method
                    metho = DirectCast(DirectCast(sta, CodeDom.CodeExpressionStatement).Expression, CodeDom.CodeMethodInvokeExpression)
                    If metho.Method.MethodName = "WriteLine" AndAlso TypeOf metho.Method.TargetObject Is CodeDom.CodeTypeReferenceExpression AndAlso DirectCast(metho.Method.TargetObject, CodeDom.CodeTypeReferenceExpression).Type.BaseType = "System.Console" Then
                        If metho.Parameters.Count > 0 AndAlso TypeOf metho.Parameters(0) Is CodeDom.CodePrimitiveExpression Then
                            Me.ActionTextBox1.Text = DirectCast(metho.Parameters(0), CodeDom.CodePrimitiveExpression).Value
                        End If
                    End If

                End If
            Next

        End If
    End Sub

End Class