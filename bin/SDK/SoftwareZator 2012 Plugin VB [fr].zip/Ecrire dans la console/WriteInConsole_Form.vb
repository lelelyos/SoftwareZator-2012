﻿Public Class WriteInConsole_Form
    Inherits VelerSoftware.Plugins3.ActionForm

    ' Cette Sub est exécutée lorsque le formulaire s'ouvre. 
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        With Me
            .CancelButtonText = RM.GetString("CancelButtonText")
            .Title = RM.GetString("DisplayName")
            .Help_File = RM.GetString("Help_File")

            .ParseCode_Button_Visible = True

            ' Ici, l'initialisation du formulaire.
            ' Vous devez charger les valeurs des propriétés Param# de cette classe

            .ActionTextBox1.Tools = .Tools

            .ActionTextBox1.Text = ""

            If Not .Param1 = Nothing Then .ActionTextBox1.Text = .Param1
        End With
    End Sub

    ' Cette Sub est exécutée quand l'utilisateur clique sur le bouton OK
    Private Sub Form1_OnOKButtonClicked(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.OnOKButtonClicked
        With Me
            ' Ici, vous devez tester si l'utilisateur a rempli le formulaire
            ' et enregistrer les données de l'utilisateur dans les propriétés Param# de cette classe.
            ' Ces propriétés seront utilisées par la classe d'action pour enregistrer
            ' les paramètres de votre action

            If .ActionTextBox1.Text = Nothing Then
                MsgBox(RM.GetString("Incompleted_Form"), MsgBoxStyle.Exclamation)
                Exit Sub
            End If

            .Param1 = .ActionTextBox1.Text

            .DialogResult = Windows.Forms.DialogResult.OK
            .Close()
        End With
    End Sub

    ' Cette Sub est exécutée lorsque l'utilisateur clique sur le bouton Annuler
    Private Sub Form1_OnCancelButtonClicked(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.OnCancelButtonClicked
        With Me
            .DialogResult = Windows.Forms.DialogResult.Cancel
            .Close()
        End With
    End Sub

    ' Cette Sub est exécutée quand l'utilisateur veut visualiser le code VB.Net et clique sur le bouton Actualiser
    Private Sub Form1_OnRefreshCodeButtonClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.OnRefreshCodeButtonClick
        ' Ici, vous devez (avec CodeDom ou non) générer le code Visual Basic.Net selon
        ' ce que l'utilisateur a écrit dans le formulaire.

        If Me.ActionTextBox1.Text = Nothing Then
            MsgBox(RM.GetString("Incompleted_Form"), MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        Dim sourceWriter As New IO.StringWriter()

        CodeDom.Compiler.CodeDomProvider.CreateProvider("VB").GenerateCodeFromExpression(New CodeDom.CodeMethodInvokeExpression(New CodeDom.CodeMethodReferenceExpression(New CodeDom.CodeTypeReferenceExpression("System.Console"), "WriteLine"), New CodeDom.CodeSnippetExpression(Me.Tools.TransformKeyVariables(Me.ActionTextBox1.Text, True))), sourceWriter, New CodeDom.Compiler.CodeGeneratorOptions())

        sourceWriter.Close()

        Me.CodeEditor_Text = sourceWriter.ToString
    End Sub

    ' Cette Sub est exécutée quand l'utilisateur veut modifier les paramètres de l'action selon le code VB.Net
    Private Sub Form1_OnParseCodeButtonClick(ByVal sender As CodeDom.CodeCompileUnit, ByVal e As System.EventArgs) Handles MyBase.OnParseCodeButtonClick
        If (Not sender Is Nothing) AndAlso (sender.Namespaces.Count > 0) Then

            ' Ici, vous devez écrire un algorithme pour recharger le formulaire avec le code VB.Net
            ' en utilisant exclusivement System.CodeDom. 

            Dim metho As CodeDom.CodeMethodInvokeExpression
            For Each sta As CodeDom.CodeStatement In DirectCast(sender.Namespaces(0).Types(0).Members(0), CodeDom.CodeMemberMethod).Statements
                If TypeOf sta Is CodeDom.CodeExpressionStatement AndAlso TypeOf DirectCast(sta, CodeDom.CodeExpressionStatement).Expression Is CodeDom.CodeMethodInvokeExpression Then
                    ' Si c'est une méthode
                    metho = DirectCast(DirectCast(sta, CodeDom.CodeExpressionStatement).Expression, CodeDom.CodeMethodInvokeExpression)
                    If metho.Method.MethodName = "WriteLine" AndAlso TypeOf metho.Method.TargetObject Is CodeDom.CodeTypeReferenceExpression AndAlso DirectCast(metho.Method.TargetObject, CodeDom.CodeTypeReferenceExpression).Type.BaseType = "System.Console" Then
                        If metho.Parameters.Count > 0 AndAlso TypeOf metho.Parameters(0) Is CodeDom.CodePrimitiveExpression Then
                            Me.ActionTextBox1.Text = DirectCast(metho.Parameters(0), CodeDom.CodePrimitiveExpression).Value
                        End If
                    End If

                End If
            Next

        End If
    End Sub

End Class