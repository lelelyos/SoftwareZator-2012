﻿Public Class WriteInConsole_Designer

    Private Sub ActionChanged(ByVal sender As System.Object, ByVal propertyName As String, ByVal e As System.EventArgs)
        If propertyName = "Param1" Then Me.TextBox1.Text = DirectCast(Me.ModelItem.GetCurrentValue, WriteInConsole).Param1
    End Sub

    Private Sub ActivityDesigner_Loaded(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles MyBase.Loaded
        ' Initialisation de la langue et des ressources
        System.Threading.Thread.CurrentThread.CurrentUICulture = VelerSoftware.Plugins3.CurrentCulture
        RM = New System.Resources.ResourceManager("$safeprojectname$.WriteInConsole", GetType(WriteInConsole).Assembly)

        Me.TextBlock1.Text = RM.GetString("Designer_Collaspe")
        Me.Label2.Content = RM.GetString("Designer_Label")

        Me.TextBox1.Text = DirectCast(Me.ModelItem.GetCurrentValue, WriteInConsole).Param1

        AddHandler DirectCast(Me.ModelItem.GetCurrentValue, WriteInConsole).ActionChanged, AddressOf ActionChanged
    End Sub

End Class
