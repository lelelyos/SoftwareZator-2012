﻿Module Variables

    Public RM As System.Resources.ResourceManager = Nothing

End Module
