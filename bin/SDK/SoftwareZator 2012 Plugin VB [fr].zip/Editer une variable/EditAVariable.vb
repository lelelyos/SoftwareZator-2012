﻿' La ligne ci-dessous définit le concepteur de l'action (un fichier Action_Designer.xaml) à utiliser pour l'éditeur d'action.
<System.ComponentModel.Designer(GetType(EditAVariable_Designer))> _
Public Class EditAVariable
    ' Ce fichier est lui-même une «action». C'est là qu'est défini les principales propriétés de l'action. Pour définir une classe comme une
    ' action, vous devez hériter de cette classe de "VelerSoftware.Plugins3.Action" (après avoir ajouté la référence 
    ' "VelerSoftware.Plugins3.dll" au projet.
    Inherits VelerSoftware.Plugins3.Action

    ' Le Sub "New" est effectuée lors de l'initialisation de l'action, à l'ouverture de SoftwareZator, avant qu'il ne soit chargé dans la boîte à outils.
    ' C'est ici qu'on définit le titre de l'action, son icône, description, catégorie, les paramètres de reconnaissance vocale et plus encore.
    Public Sub New()
        ' Initialisation de la langue et les ressources
        System.Threading.Thread.CurrentThread.CurrentUICulture = VelerSoftware.Plugins3.CurrentCulture
        RM = New System.Resources.ResourceManager("$safeprojectname$.EditAVariable", GetType(EditAVariable).Assembly)

        ' Initialisation des Propriétés de bases de l'action
        With Me
            .DisplayName = RM.GetString("DisplayName") ' Nom affiché dans la boîte à outils
            .Description = RM.GetString("Description") ' Description affiché dans la boîte à outils
            .Category = RM.GetString("Category") ' Catégorie de l'action
            .ToolBoxImage = My.Resources.EditAVariable ' Icône de l'action
            .CompatibleClass = False ' Si cette propriété est True, cette action sera affiché dans la boîte à outils lorsque l'utilisateur est à la racine (premier onglet) de l'éditeur de fonctions
            .CompatibleFonctions = True ' Si cette propriété est True, cette action sera montré dans la boite à outils lorsque l'utilisateur est dans une autre fonction
            .FileHelp = RM.GetString("Help_File") ' Définit le fichier HTML de la documentation de l'action

            .Voice_Recognition_Dictionary.Add(RM.GetString("Dictionary1")) ' Add a word to the dictionary for the voice recognition
            .Voice_Recognition_Dictionary.Add(RM.GetString("Dictionary2"))
        End With
    End Sub

    ' La fonction "Main" est exécutée lorsque l'action est ajouté à l'éditeur d'action. Son but est de demander à l'utilisateur de la paramétrer, le plus souvent par 
    ' l'affichage d'une fenêtre à l'écran. On retourne ensuite une valeur booléenne permettant de savoir si SoftwareZator peut ajouter l'action à
    ' l'éditeur de l'action ou si l'utilisateur a annulé l'ajout de cette action.
    Public Overrides Function Main() As Boolean
        ' Initialisation de la langue et des ressources
        System.Threading.Thread.CurrentThread.CurrentUICulture = VelerSoftware.Plugins3.CurrentCulture
        RM = New System.Resources.ResourceManager("$safeprojectname$.EditAVariable", GetType(EditAVariable).Assembly)

        ' Affichage de la fenêtre de réglage de l'action
        Using frm As New EditAVariable_Form
            frm.Tools = Me.Tools ' La propriété Tools permet d'utiliser les différentes fonctions issues de VelerSoftware.Plugins3.Tools
            If frm.ShowDialog = Windows.Forms.DialogResult.OK Then
                Me.UseCustomVBCode = frm.CodeEditor_Used
                Me.CustomVBCode = New CodeDom.CodeSnippetStatement(frm.CodeEditor_Text)
                Me.Param1 = frm.Param1 ' Récupérer un paramètre pour l'enregistrer  
                Me.Param2 = frm.Param2
                Me.Param3 = frm.Param3
                Me.Param4 = frm.Param4

                Return True
            Else
                Return False
            End If
            frm.Dispose()
        End Using
    End Function

    ' La fonction "Modifier" est exécutée lorsque l'utilisateur clique sur le bouton "Modifier les paramètres de l'action". Son but est de demander à l'utilisateur de
    ' paramétrer l'action, généralement par l'affichage d'une fenêtre sur l'écran. On retourne ensuite une valeur booléenne permettant de savoir si SoftwareZator peut
    ' modifier les paramètres de l'action dans l'éditeur de l'action ou si l'utilisateur a annulé.
    Public Overrides Function Modify() As Boolean
        ' Initialisation de la langue et des ressources
        System.Threading.Thread.CurrentThread.CurrentUICulture = VelerSoftware.Plugins3.CurrentCulture
        RM = New System.Resources.ResourceManager("$safeprojectname$.EditAVariable", GetType(EditAVariable).Assembly)

        ' Affichage de la fenêtre de réglage de l'action
        Using frm As New EditAVariable_Form
            frm.Tools = Me.Tools ' La propriété Tools permet d'utiliser les différentes fonctions issues de VelerSoftware.Plugins3.Tools
            frm.Param1 = Me.Param1
            frm.Param2 = Me.Param2
            frm.Param3 = Me.Param3
            frm.Param4 = Me.Param4
            frm.CodeEditor_Shown = Me.UseCustomVBCode
            frm.CodeEditor_Used = Me.UseCustomVBCode

            ' Chargez le code VB.Net
            Dim sourceWriter As New IO.StringWriter()
            If Not Me.CustomVBCode Is Nothing Then CodeDom.Compiler.CodeDomProvider.CreateProvider("VB").GenerateCodeFromStatement(Me.CustomVBCode, sourceWriter, New CodeDom.Compiler.CodeGeneratorOptions())
            sourceWriter.Close()
            frm.CodeEditor_Text = sourceWriter.ToString

            If frm.ShowDialog = Windows.Forms.DialogResult.OK Then
                Me.UseCustomVBCode = frm.CodeEditor_Used
                Me.CustomVBCode = New CodeDom.CodeSnippetStatement(frm.CodeEditor_Text)
                Me.Param1 = frm.Param1 ' Récupérer un paramètre pour l'enregistrer  
                Me.Param2 = frm.Param2
                Me.Param3 = frm.Param3
                Me.Param4 = frm.Param4

                Return True
            Else
                Return False
            End If
            frm.Dispose()
        End Using
    End Function

    ' La fonction "GetVBCode" est appelée par SoftwareZator au moment de la génération d'un projet de générer le code Visual Basic.Net
    ' de l'action à compiler. Le paramètre "FromFunction" défini si l'action est dans une fonction ou à la racine d'un document.
    ' Vous devez retourner une valeur CodeDom. Pour plus d'informations sur CodeDom:   
    ' http://msdn.microsoft.com/en-us/library/system.codedom(v=vs.100).aspx
    Public Overrides Function GetVBCode(ByVal FromFunction As Boolean) As System.CodeDom.CodeObject
        If Me.UseCustomVBCode Then
            Return Me.CustomVBCode
        Else
            If FromFunction Then
                ' Retourne une valeur CodeDom qui génère le code VB.Net suivant : Votre_Variable = 1 avec "Votre_Variable", avec la valeur de Param1.
                Dim VariableStatement As New CodeDom.CodeVariableReferenceExpression(Me.Param1)
                Dim NewValueStatement As New CodeDom.CodeSnippetExpression(Me.Param3)
                Return New CodeDom.CodeAssignStatement(VariableStatement, NewValueStatement)
            Else
                Return Nothing
            End If
        End If
    End Function

    ' La fonction "ResolveError" est appelée lorsque l'utilisateur veut que SoftwareZator corrige automatiquement une erreur de génération liée à cette action.
    ' Dans cette fonction, vous devez écrire un algorithme conçu pour identifier le problème avec le paramètre "ErrorToResolve", qui
    ' fournit des informations sur l'erreur et permet de se référer à l'information de SoftwareZator lié à la correction,
    ' comme une explication de l'erreur par exemple.
    Public Overrides Function ResolveError(ByVal ErrorToResolve As VelerSoftware.SZVB.Projet.Erreur, ByVal e As System.EventArgs) As Boolean
        Dim result As Boolean
        Dim i_progress, i2_progress As Integer
        i_progress = 0
        i2_progress = 0

        System.Threading.Thread.CurrentThread.CurrentUICulture = VelerSoftware.Plugins3.CurrentCulture
        RM = New System.Resources.ResourceManager("$safeprojectname$.EditAVariable", GetType(EditAVariable).Assembly)

        If ErrorToResolve.Type = VelerSoftware.SZVB.Projet.Erreur.ErrorType.Building Then

            If ErrorToResolve.ErrorNumber = "BC30451" Then ' La variable n'existe plus 
                Dim oki As Boolean
                For Each var As VelerSoftware.SZVB.Projet.Variable In Tools.GetCurrentProjectVariableList
                    If var.Name = Me.Param1 Then oki = True
                Next
                If Not oki Then Tools.GetCurrentProjectVariableList.Add(New VelerSoftware.SZVB.Projet.Variable(Me.Param1, False, Nothing, Nothing))
                ErrorToResolve.ErrorExplain = "The variable does not exist" ' Ici, on explique l'erreur
                ErrorToResolve.ErrorSolutionExplain = "The variable has been added to Variables Manager" ' Et ici, quelle correction a été trouvé

                Return True

            Else
                Return False

            End If

        End If

        Return result
    End Function

End Class
