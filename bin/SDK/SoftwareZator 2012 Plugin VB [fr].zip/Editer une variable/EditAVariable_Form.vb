﻿Public Class EditAVariable_Form
    Inherits VelerSoftware.Plugins3.ActionForm

    ' Cette Sub est exécutée lorsque le formulaire s'ouvre. 
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        With Me
            .CancelButtonText = RM.GetString("CancelButtonText")
            .Title = RM.GetString("DisplayName")
            .Help_File = RM.GetString("Help_File")

            .ParseCode_Button_Visible = True
               
            ' Ici, l'initialisation du formulaire.
            ' Vous devez charger les valeurs des propriétés Param# de cette classe

            .ValueEdit1.Tools = .Tools

            .ComboBox1.SelectedIndex = 0
            .ComboBox1.Items.Clear()
            For Each a As VelerSoftware.SZVB.Projet.Variable In .Tools.GetCurrentProjectVariableList
                If Not a.Array Then
                    .ComboBox1.Items.Add(a.Name)
                End If
            Next

            If Not .Param1 = Nothing Then
                If Not .ComboBox1.FindString(.Param1) = -1 Then
                    .ComboBox1.Text = .ComboBox1.Items(.ComboBox1.FindString(.Param1))
                End If
            End If

            If Not .Param3 = Nothing Then
                .ValueEdit1.SetGeneratedCode(.Param3)
            End If

            If Not .Param2 = Nothing Then
                .ValueEdit1.SetStrictValue(.Param2, CInt(.Param4))
            End If
        End With
    End Sub

    ' Cette Sub est exécutée quand l'utilisateur clique sur le bouton OK
    Private Sub Form1_OnOKButtonClicked(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.OnOKButtonClicked
        With Me
            ' Ici, vous devez tester si l'utilisateur a rempli le formulaire
            ' et enregistrer les données de l'utilisateur dans les propriétés Param# de cette classe.
            ' Ces propriétés seront utilisées par la classe d'action pour enregistrer
            ' les paramètres de votre action

            If .ComboBox1.Text = Nothing Then
                MsgBox(RM.GetString("Incompleted_Form"), MsgBoxStyle.Exclamation)
                Exit Sub
            End If

            .Param1 = .ComboBox1.Text
            .Param2 = .ValueEdit1.GetStrictValue()
            .Param4 = CInt(.ValueEdit1.Editor)
            .Param3 = .ValueEdit1.GetGeneratedCode()

            .DialogResult = Windows.Forms.DialogResult.OK
            .Close()
        End With
    End Sub

    ' Cette Sub est exécutée lorsque l'utilisateur clique sur le bouton Annuler
    Private Sub Form1_OnCancelButtonClicked(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.OnCancelButtonClicked
        With Me
            .DialogResult = Windows.Forms.DialogResult.Cancel
            .Close()
        End With
    End Sub

    ' Cette Sub est exécutée quand l'utilisateur veut visualiser le code VB.Net et clique sur le bouton Actualiser
    Private Sub Form1_OnRefreshCodeButtonClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.OnRefreshCodeButtonClick
        ' Ici, vous devez (avec CodeDom ou non) générer le code Visual Basic.Net selon
        ' ce que l'utilisateur a écrit dans le formulaire.

        If Me.ComboBox1.Text = Nothing Then
            MsgBox(RM.GetString("Incompleted_Form"), MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        Dim sourceWriter As New IO.StringWriter()

        Dim VariableStatement As New CodeDom.CodeVariableReferenceExpression(Me.ComboBox1.Text)
        Dim NewValueStatement As New CodeDom.CodeSnippetExpression(Me.ValueEdit1.GetGeneratedCode())
        Dim OperationStatement As New CodeDom.CodeAssignStatement(VariableStatement, NewValueStatement)
        CodeDom.Compiler.CodeDomProvider.CreateProvider("VB").GenerateCodeFromStatement(OperationStatement, sourceWriter, New CodeDom.Compiler.CodeGeneratorOptions())

        sourceWriter.Close()

        Me.CodeEditor_Text = sourceWriter.ToString
    End Sub

    ' Cette Sub est exécutée quand l'utilisateur veut modifier les paramètres de l'action selon le code VB.Net
    Private Sub Form1_OnParseCodeButtonClick(ByVal sender As CodeDom.CodeCompileUnit, ByVal e As System.EventArgs) Handles MyBase.OnParseCodeButtonClick
        If (Not sender Is Nothing) AndAlso (sender.Namespaces.Count > 0) Then

            ' Ici, vous devez écrire un algorithme pour recharger le formulaire avec le code VB.Net
            ' en utilisant exclusivement System.CodeDom. 

            Dim metho As CodeDom.CodeAssignStatement
            For Each sta As CodeDom.CodeStatement In DirectCast(sender.Namespaces(0).Types(0).Members(0), CodeDom.CodeMemberMethod).Statements

                If TypeOf sta Is CodeDom.CodeAssignStatement Then
                    metho = DirectCast(sta, CodeDom.CodeAssignStatement)
                    If TypeOf metho.Left Is CodeDom.CodeVariableReferenceExpression Then
                        Me.ComboBox1.Text = DirectCast(metho.Left, CodeDom.CodeVariableReferenceExpression).VariableName
                    End If
                End If
            Next

        End If
    End Sub

End Class